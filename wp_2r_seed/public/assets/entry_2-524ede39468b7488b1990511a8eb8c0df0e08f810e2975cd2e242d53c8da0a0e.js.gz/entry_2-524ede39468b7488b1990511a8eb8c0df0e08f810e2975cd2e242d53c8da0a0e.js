webpackJsonp([1],[
/* 0 */
/*!*********************************************!*\
  !*** ./app/frontend/javascripts/entry_2.js ***!
  \*********************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	var _lodash = __webpack_require__(/*! lodash */ 2);
	
	var _lodash2 = _interopRequireDefault(_lodash);
	
	var _react = __webpack_require__(/*! react */ 4);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactDom = __webpack_require__(/*! react-dom */ 161);
	
	var _reactDom2 = _interopRequireDefault(_reactDom);
	
	var _world = __webpack_require__(/*! ./components/world */ 162);
	
	var _world2 = _interopRequireDefault(_world);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	__webpack_require__(/*! expose?$!expose?jQuery!jquery */ 163);

/***/ }
]);
//# sourceMappingURL=entry_2.js.map
